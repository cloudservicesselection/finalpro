package myskylineapp;
public class DoublePoint {

      public double x, y, z, v, o, w, q, r, t, p, k;                     //the coordinates of each point

      
    public DoublePoint next, node;          //next link in list
   
    
        private double min_availabilty = 90.0;
	private double max_availabilty = 100.0;
	private double min_throuput = 25.0;
	private double max_throuput = 50.0;
	private double min_security = 19.0;
	private double max_security = 23.0;
	private double min_responce = 100.0;
	private double max_responce = 22.0;
        private double min_cost = 321.0;
	private double max_cost = 1500.0;
	private double min_accessability = 85.0;
	private double max_accessability = 100.0;
	private double min_storage = 1000.0;
	private double max_storage = 2400.0;
	private double min_speed = 1.9;
	private double max_speed = 4.0;
	private double min_documentation = 32.0;
	private double max_documentation = 94.0;
	private double min_ram = 80.0;
	private double max_ram = 150.0;
	private double min_processorCore = 8.0;
	private double max_processorCore = 32.0;
    
    public DoublePoint() {
        x = (int) (Math.random() * ((10) + 1));
        y = (int) (Math.random() * ((10) + 1));
        z = (int) (Math.random() * ((10) + 1));
        v = (int) (Math.random() * ((10) + 1));
        o = (int) (Math.random() * ((10) + 1));
        w = (int) (Math.random() * ((10) + 1));
        q = (int) (Math.random() * ((10) + 1));
        r = (int) (Math.random() * ((10) + 1));
        t = (int) (Math.random() * ((10) + 1));
        p = (int) (Math.random() * ((10) + 1));
        k = (int) (Math.random() * ((10) + 1));
        
        
        
        
        
    }
    
    public DoublePoint(double diastasi1, double diastasi2 ,double diastasi3 ,double diastasi4 ,double diastasi5 ,double diastasi6 ,double diastasi7 ,double diastasi8 ,double diastasi9 ,double diastasi10 ,double diastasi11 ) {
        x = diastasi1;
        y = diastasi2;
        z = diastasi3;
        v = diastasi4;
        o = diastasi5;
        w = diastasi6;
        q = diastasi7;
        r = diastasi8;
        t = diastasi9;
        p = diastasi10;
        k = diastasi11;
    }

    public DoublePoint dominate(DoublePoint q) {
        if(intervallContains(min_availabilty,max_availabilty,this.x) && intervallContains(min_throuput,max_throuput,this.y) && intervallContains(min_security,max_security,this.z) && intervallContains(min_responce,max_responce,this.o) && intervallContains(min_cost,max_cost,this.v) && intervallContains(min_accessability,max_accessability,this.q) && intervallContains(min_storage,max_storage,this.w) && intervallContains(min_speed,max_speed,this.r) && intervallContains(min_documentation,max_documentation,this.t) && intervallContains(min_ram,max_ram,this.p) && intervallContains(min_processorCore,max_processorCore,this.k) )
            {
            if ((this.x >= q.x && this.y > q.y && this.z > q.z && this.o < q.o && this.w > q.w && this.q > q.q && this.v < q.v && this.r > q.r && this.t > q.t && this.p > q.p && this.k > q.k ) ||
                (this.x > q.x && this.y >= q.y && this.z > q.z && this.o < q.o && this.w > q.w && this.q > q.q && this.v < q.v && this.r > q.r && this.t > q.t && this.p > q.p && this.k > q.k ) ||  
                (this.x > q.x && this.y > q.y && this.z >= q.z && this.o < q.o && this.w > q.w && this.q > q.q && this.v < q.v && this.r > q.r && this.t > q.t && this.p > q.p && this.k > q.k ) ||
                (this.x > q.x && this.y > q.y && this.z > q.z && this.o <= q.o && this.w > q.w && this.q > q.q && this.v < q.v && this.r > q.r && this.t > q.t && this.p > q.p && this.k > q.k ) ||
                (this.x > q.x && this.y > q.y && this.z > q.z && this.o < q.o && this.w >= q.w && this.q > q.q && this.v < q.v && this.r > q.r && this.t > q.t && this.p > q.p && this.k > q.k ) ||
                (this.x > q.x && this.y > q.y && this.z > q.z && this.o < q.o && this.w > q.w && this.q >= q.q && this.v < q.v && this.r > q.r && this.t > q.t && this.p > q.p && this.k > q.k ) ||
                (this.x > q.x && this.y > q.y && this.z > q.z && this.o < q.o && this.w > q.w && this.q > q.q && this.v <= q.v && this.r > q.r && this.t > q.t && this.p > q.p && this.k > q.k ) ||
                (this.x > q.x && this.y > q.y && this.z > q.z && this.o < q.o && this.w > q.w && this.q > q.q && this.v < q.v && this.r >= q.r && this.t > q.t && this.p > q.p && this.k > q.k ) ||
                (this.x > q.x && this.y > q.y && this.z > q.z && this.o < q.o && this.w > q.w && this.q > q.q && this.v < q.v && this.r > q.r && this.t >= q.t && this.p > q.p && this.k > q.k ) ||
                (this.x > q.x && this.y > q.y && this.z > q.z && this.o < q.o && this.w > q.w && this.q > q.q && this.v < q.v && this.r > q.r && this.t > q.t && this.p >= q.p && this.k > q.k ) ||
                (this.x > q.x && this.y > q.y && this.z > q.z && this.o < q.o && this.w > q.w && this.q > q.q && this.v < q.v && this.r > q.r && this.t > q.t && this.p > q.p && this.k >= q.k ) ||
                (this.x > q.x && this.y > q.y && this.z > q.z && this.o < q.o && this.w > q.w && this.q > q.q && this.v < q.v && this.r > q.r && this.t > q.t && this.p > q.p && this.k > q.k )
                    ) {
                            return this;
           }
       }
        return null;
    }

    public void displayNode(int count) {
        System.out.println(count + "{" + this.x + "," + this.y + "," + this.z + "," + this.o + "," + this.v + "," + this.w + "," + this.q + "," + this.r + "," + this.t + "," + this.p + "," + this.k + "}");
   count++;
    }
    
public static boolean intervallContains(double low, double high, double n) {
    return n >= low && n <= high;
}

}
