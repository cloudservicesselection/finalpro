package myskylineapp;

/**
 *
 * @author kostas livieratos
 */
public class ListDoublePoints {

    public DoublePoint first;     //reference to first link of list
    public int count=0;
    
    public ListDoublePoints() {
        first = null;
    }

    /**
     *
     * @param diastasi1
     * @param diastasi2
     * @param diastasi3
     * @param diastasi4
     * @param diastasi5
     * @param diastasi6
     * @param diastasi7
     * @param diastasi8
     * @param diastasi9
     * @param diastasi10
     * @param diastasi11
     * 
     */
   
    public void insertFirst(double diastasi1, double diastasi2 ,double diastasi3 ,double diastasi4 ,double diastasi5 ,double diastasi6 ,double diastasi7 ,double diastasi8 ,double diastasi9 ,double diastasi10 ,double diastasi11 ) {
        DoublePoint newPoint = new DoublePoint(diastasi1, diastasi2, diastasi3, diastasi4, diastasi5, diastasi6, diastasi7, diastasi8, diastasi9, diastasi10, diastasi11 );
        newPoint.next = first;
        first = newPoint;
    }

    public DoublePoint delete(DoublePoint node) {
        DoublePoint current = first;
        DoublePoint previous = first;

        while (current != node) {
            if (current.next == null) {
                return null;
            } else {
                previous = current;
                current = current.next;
            }
        }

        if (current == first) {
            first = first.next;
        } else {
            previous.next = current.next;
        }

        return current;

    }
    
    public DoublePoint extractFirst() {
        return first;
    }
    
    public void append(DoublePoint result) {
        first = result;
    }

    public void displayList() {
        System.out.println("List (first-->last):");
        DoublePoint current = first;
        while (current != null) {
            
            current.displayNode(count);
            current = current.next;
            count++;
        }
        System.out.println();
    }
}
