package myskylineapp;

import java.io.BufferedReader;
import java.util.Date;
import java.io.File.*;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

import java.io.File.*;
import java.io.IOException;

/**
 *
 * @author kostas livieratos
 */
public class MySkylineApp {

    /**
     * @param args the command line arguments
     */
  

    public static void main(String[] args) {
        //  int N = 10; //we do not need to care about the value of N,by the time we read the points from a file (*.txt)
        Scanner input = new Scanner(System.in);
        //for (N = 10; N <= 100; N = N * 10) {
        ListDoublePoints P = new ListDoublePoints();
        long algtm1;
        int count=0;
        String path, line = null;
        try {
            System.out.printf("Give the name of txt file :");
            path = input.next();
            FileReader reader = new FileReader(path+".txt");
            BufferedReader br = new BufferedReader(reader);
            while ((line = br.readLine()) != null) {
                count++;
                String[] parts = line.split(" ");
                float diastasi1 = (float)Float.parseFloat(parts[1]);
                float diastasi2 = (float)Float.parseFloat(parts[2]);
                float diastasi3 = (float)Float.parseFloat(parts[3]);
                float diastasi4 = (float)Float.parseFloat(parts[4]);
                float diastasi5 = (float)Float.parseFloat(parts[5]);
                float diastasi6 = (float)Float.parseFloat(parts[6]);
                float diastasi7 = (float)Float.parseFloat(parts[7]);
                float diastasi8 = (float)Float.parseFloat(parts[8]);
                float diastasi9 = (float)Float.parseFloat(parts[9]);
                float diastasi10 = (float)Float.parseFloat(parts[10]);
                float diastasi11 = (float)Float.parseFloat(parts[11]);                
                P.insertFirst(diastasi1, diastasi2, diastasi3, diastasi4, diastasi5, diastasi6, diastasi7, diastasi8, diastasi9, diastasi10, diastasi11 );
            }
            br.close();
        } catch (Exception e) {
            System.out.println(e.toString());
        }
        Date d1alg1 = new Date();
        SkylineAlg1 alg1 = new SkylineAlg1();
        alg1.dominating(P);
        Date d2alg1 = new Date();
        P.displayList();
        algtm1 = d2alg1.getTime() - d1alg1.getTime();
        System.out.printf("First skyline algorithm time: %s%s\n", algtm1, " milliseconds");
        System.out.printf("input:  %s%s\n",count," rows");
        System.out.printf("\n");
        

    }

}
